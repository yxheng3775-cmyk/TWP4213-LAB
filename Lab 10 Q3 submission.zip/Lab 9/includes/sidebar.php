<div class="sidebar">
        <div class="sidebar-header">
            <h2>Lakeshow Grocery</h2>
        </div>
        <div class="sidebar-menu">
            <h3>Dashboard</h3>
            <ul>
                <li><a href="Dashboard.php">Overview</a></li>             
                <li><a href="Customer.php">Customer Management</a></li>
                <li><a href="Product.php" class="active">Products Management</a></li>
                <li><a href="Categories.php">Categories Management</a></li>
                <li><a href="Order.php">Orders Management</a></li>
                <li><a href="Logout.php">Logout</a></li>
            </ul>
        </div>
    </div>